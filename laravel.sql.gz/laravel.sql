-- Adminer 4.7.8 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cities_state_id_foreign` (`state_id`),
  CONSTRAINT `cities_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cities` (`id`, `name`, `state_id`, `created_at`, `updated_at`) VALUES
('bd7797a5-4b7b-11f0-b71a-c43d1a5545f6',	'Los Angeles',	'5450e940-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd779c98-4b7b-11f0-b71a-c43d1a5545f6',	'San Diego',	'5450e940-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd779e42-4b7b-11f0-b71a-c43d1a5545f6',	'San Jose',	'5450e940-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd781e3a-4b7b-11f0-b71a-c43d1a5545f6',	'Mumbai',	'6447ac30-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd782307-4b7b-11f0-b71a-c43d1a5545f6',	'Pune',	'6447ac30-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd782519-4b7b-11f0-b71a-c43d1a5545f6',	'Nagpur',	'6447ac30-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd786b3b-4b7b-11f0-b71a-c43d1a5545f6',	'Toronto',	'70caa02a-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd78709e-4b7b-11f0-b71a-c43d1a5545f6',	'Mississauga',	'70caa02a-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd7872a3-4b7b-11f0-b71a-c43d1a5545f6',	'Ottawa',	'70caa02a-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd78c99c-4b7b-11f0-b71a-c43d1a5545f6',	'Sydney',	'7e518521-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd78cd7f-4b7b-11f0-b71a-c43d1a5545f6',	'Newcastle',	'7e518521-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd78cea7-4b7b-11f0-b71a-c43d1a5545f6',	'Wollongong',	'7e518521-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd792440-4b7b-11f0-b71a-c43d1a5545f6',	'Munich',	'8b378ed4-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd792c00-4b7b-11f0-b71a-c43d1a5545f6',	'Nuremberg',	'8b378ed4-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28'),
('bd792da9-4b7b-11f0-b71a-c43d1a5545f6',	'Augsburg',	'8b378ed4-4b7b-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:05:28',	'2025-06-17 13:05:28');

DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `countries` (`id`, `name`, `created_at`, `updated_at`) VALUES
('f79e28d3-4b7a-11f0-b71a-c43d1a5545f6',	'United States',	'2025-06-17 12:59:56',	'2025-06-17 12:59:56'),
('f79e2e65-4b7a-11f0-b71a-c43d1a5545f6',	'India',	'2025-06-17 12:59:56',	'2025-06-17 12:59:56'),
('f79e301b-4b7a-11f0-b71a-c43d1a5545f6',	'Canada',	'2025-06-17 12:59:56',	'2025-06-17 12:59:56'),
('f79e3117-4b7a-11f0-b71a-c43d1a5545f6',	'Australia',	'2025-06-17 12:59:56',	'2025-06-17 12:59:56'),
('f79e386e-4b7a-11f0-b71a-c43d1a5545f6',	'Germany',	'2025-06-17 12:59:56',	'2025-06-17 12:59:56');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'0001_01_01_000001_create_cache_table',	1),
(2,	'0001_01_01_000002_create_jobs_table',	1),
(3,	'2025_06_17_120729_create_countries_table',	1),
(4,	'2025_06_18_120729_create_states_table',	1),
(5,	'2025_06_19_120729_create_cities_table',	1),
(6,	'2026_01_01_000000_create_users_table',	1);

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_session_id_unique` (`session_id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `states`;
CREATE TABLE `states` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `states_country_id_foreign` (`country_id`),
  CONSTRAINT `states_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `states` (`id`, `name`, `country_id`, `created_at`, `updated_at`) VALUES
('5450e940-4b7b-11f0-b71a-c43d1a5545f6',	'California',	'f79e28d3-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:02:31',	'2025-06-17 13:02:31'),
('5450eea2-4b7b-11f0-b71a-c43d1a5545f6',	'New York',	'f79e28d3-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:02:31',	'2025-06-17 13:02:31'),
('5450efb7-4b7b-11f0-b71a-c43d1a5545f6',	'Texas',	'f79e28d3-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:02:31',	'2025-06-17 13:02:31'),
('6447ac30-4b7b-11f0-b71a-c43d1a5545f6',	'Maharashtra',	'f79e2e65-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:02:58',	'2025-06-17 13:02:58'),
('6447b0c6-4b7b-11f0-b71a-c43d1a5545f6',	'Karnataka',	'f79e2e65-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:02:58',	'2025-06-17 13:02:58'),
('6447b1ea-4b7b-11f0-b71a-c43d1a5545f6',	'Delhi',	'f79e2e65-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:02:58',	'2025-06-17 13:02:58'),
('70caa02a-4b7b-11f0-b71a-c43d1a5545f6',	'Ontario',	'f79e301b-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:03:19',	'2025-06-17 13:03:19'),
('70caa5a4-4b7b-11f0-b71a-c43d1a5545f6',	'British Columbia',	'f79e301b-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:03:19',	'2025-06-17 13:03:19'),
('70caa66b-4b7b-11f0-b71a-c43d1a5545f6',	'Alberta',	'f79e301b-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:03:19',	'2025-06-17 13:03:19'),
('7e518521-4b7b-11f0-b71a-c43d1a5545f6',	'New South Wales',	'f79e3117-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:03:42',	'2025-06-17 13:03:42'),
('7e518eef-4b7b-11f0-b71a-c43d1a5545f6',	'Victoria',	'f79e3117-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:03:42',	'2025-06-17 13:03:42'),
('7e51915e-4b7b-11f0-b71a-c43d1a5545f6',	'Queensland',	'f79e3117-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:03:42',	'2025-06-17 13:03:42'),
('8b378ed4-4b7b-11f0-b71a-c43d1a5545f6',	'Bavaria',	'f79e386e-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:04:03',	'2025-06-17 13:04:03'),
('8b3794a6-4b7b-11f0-b71a-c43d1a5545f6',	'Berlin',	'f79e386e-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:04:03',	'2025-06-17 13:04:03'),
('8b37954d-4b7b-11f0-b71a-c43d1a5545f6',	'Hesse',	'f79e386e-4b7a-11f0-b71a-c43d1a5545f6',	'2025-06-17 13:04:03',	'2025-06-17 13:04:03');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` enum('male','female','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_country_id_foreign` (`country_id`),
  KEY `users_state_id_foreign` (`state_id`),
  KEY `users_city_id_foreign` (`city_id`),
  CONSTRAINT `users_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2025-06-17 13:05:49
